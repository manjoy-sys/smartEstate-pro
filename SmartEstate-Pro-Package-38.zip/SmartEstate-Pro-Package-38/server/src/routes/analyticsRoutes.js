const router=require("express").Router();
router.get("/",(req,res)=>res.json({views:0,inquiries:0,bookings:0}));
module.exports=router;
