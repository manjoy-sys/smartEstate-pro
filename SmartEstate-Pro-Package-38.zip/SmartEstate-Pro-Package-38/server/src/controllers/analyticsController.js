exports.summary=async(req,res)=>res.json({views:0,inquiries:0,bookings:0});
