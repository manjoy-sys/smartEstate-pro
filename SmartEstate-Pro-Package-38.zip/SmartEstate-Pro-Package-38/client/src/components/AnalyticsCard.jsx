export default function AnalyticsCard({ title, value=0 }) {
  return <section><h3>{title}</h3><strong>{value}</strong></section>;
}
