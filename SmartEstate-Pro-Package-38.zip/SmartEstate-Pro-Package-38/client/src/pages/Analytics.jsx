export default function Analytics() {
  return (
    <main style={{padding:24}}>
      <h1>SmartEstate Analytics</h1>
      <div><strong>Views:</strong> 0</div>
      <div><strong>Inquiries:</strong> 0</div>
      <div><strong>Bookings:</strong> 0</div>
    </main>
  );
}
