# SmartEstate Pro Starter
Real-estate website starter with property search and admin dashboard.