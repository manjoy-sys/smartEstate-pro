const express=require('express');
const app=express();
app.use(express.json());
app.get('/',(_,res)=>res.json({message:'SmartEstate API'}));
app.listen(5000,()=>console.log('Server running'));
