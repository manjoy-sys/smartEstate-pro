const router = require("express").Router();

router.get("/", (req, res) => res.json({ bookings: [] }));
router.post("/", (req, res) => res.status(201).json({ booking: req.body }));

module.exports = router;
