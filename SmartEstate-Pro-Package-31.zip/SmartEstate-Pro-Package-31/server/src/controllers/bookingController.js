exports.listBookings = async (req, res) => res.json({ bookings: [] });
exports.createBooking = async (req, res) => res.status(201).json(req.body);
