export default function BookingForm({ propertyId }) {
  return (
    <form>
      <input type="date" name="date" required />
      <input type="time" name="time" required />
      <input type="hidden" name="propertyId" value={propertyId || ""} />
      <button type="submit">Book Viewing</button>
    </form>
  );
}
