import { useState } from "react";

export default function Bookings() {
  const [date, setDate] = useState("");
  const [message, setMessage] = useState("");

  function book(e) {
    e.preventDefault();
    setMessage(date ? `Viewing requested for ${date}.` : "Choose a date first.");
  }

  return (
    <main style={{padding:24}}>
      <h1>Book a Property Viewing</h1>
      <form onSubmit={book}>
        <input type="date" value={date} onChange={e => setDate(e.target.value)} />
        <button type="submit">Request Viewing</button>
      </form>
      <p>{message}</p>
    </main>
  );
}
