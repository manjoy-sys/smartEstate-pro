import { useState } from "react";

export default function Notifications() {
  const [items, setItems] = useState([]);
  return (
    <main style={{padding:24}}>
      <h1>Notifications</h1>
      {items.length ? items.map((n,i)=><p key={i}>{n.message}</p>) : <p>No new notifications.</p>}
      <button onClick={() => setItems([...items, {message:"New SmartEstate notification"}])}>Test Notification</button>
    </main>
  );
}
