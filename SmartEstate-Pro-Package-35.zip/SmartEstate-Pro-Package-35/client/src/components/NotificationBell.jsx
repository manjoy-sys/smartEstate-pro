export default function NotificationBell({ count = 0 }) {
  return <button aria-label="Notifications">🔔 {count}</button>;
}
