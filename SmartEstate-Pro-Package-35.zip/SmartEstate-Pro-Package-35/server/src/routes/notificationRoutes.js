const router = require("express").Router();
router.get("/", (req, res) => res.json({ notifications: [] }));
router.post("/", (req, res) => res.status(201).json({ notification: req.body }));
module.exports = router;
