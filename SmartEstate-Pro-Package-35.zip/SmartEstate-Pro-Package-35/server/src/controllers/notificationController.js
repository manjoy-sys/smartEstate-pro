exports.list = async (req, res) => res.json({ notifications: [] });
exports.create = async (req, res) => res.status(201).json(req.body);
