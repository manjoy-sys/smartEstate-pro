import { useState } from "react";

export default function PropertyManagement() {
  const [properties, setProperties] = useState([]);
  const [title, setTitle] = useState("");

  function add(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setProperties([...properties, {id:Date.now(), title}]);
    setTitle("");
  }

  return (
    <main style={{padding:24}}>
      <h1>Property Management</h1>
      <form onSubmit={add}>
        <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Property title" />
        <button>Add Property</button>
      </form>
      {properties.map(p=><p key={p.id}>{p.title}</p>)}
    </main>
  );
}
