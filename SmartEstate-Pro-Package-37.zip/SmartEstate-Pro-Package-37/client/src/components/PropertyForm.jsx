export default function PropertyForm() {
  return <form><input placeholder="Property title" required /><input placeholder="Price" type="number" /><button>Save Property</button></form>;
}
