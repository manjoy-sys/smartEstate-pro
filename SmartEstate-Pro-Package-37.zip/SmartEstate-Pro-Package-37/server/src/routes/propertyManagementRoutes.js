const router=require("express").Router();
router.get("/",(req,res)=>res.json({properties:[]}));
router.post("/",(req,res)=>res.status(201).json({property:req.body}));
router.put("/:id",(req,res)=>res.json({id:req.params.id,property:req.body}));
router.delete("/:id",(req,res)=>res.json({deleted:req.params.id}));
module.exports=router;
