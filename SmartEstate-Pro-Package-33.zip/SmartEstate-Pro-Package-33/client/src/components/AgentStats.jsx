export default function AgentStats({ stats = {} }) {
  return <section><p>Listings: {stats.listings || 0}</p><p>Inquiries: {stats.inquiries || 0}</p></section>;
}
