import { useState } from "react";

export default function AgentDashboard() {
  const [stats] = useState({ listings: 0, inquiries: 0, viewings: 0 });
  return (
    <main style={{padding:24}}>
      <h1>Agent Dashboard</h1>
      <div style={{display:"flex",gap:16}}>
        <div>Listings: {stats.listings}</div>
        <div>Inquiries: {stats.inquiries}</div>
        <div>Viewings: {stats.viewings}</div>
      </div>
    </main>
  );
}
