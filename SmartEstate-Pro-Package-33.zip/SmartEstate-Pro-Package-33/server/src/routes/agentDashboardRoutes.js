const router = require("express").Router();
router.get("/", (req, res) => res.json({ listings: 0, inquiries: 0, viewings: 0 }));
module.exports = router;
