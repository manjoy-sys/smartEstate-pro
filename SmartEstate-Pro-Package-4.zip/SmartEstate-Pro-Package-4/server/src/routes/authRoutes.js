const r=require('express').Router();
r.post('/login',(req,res)=>res.json({message:'TODO'}));
r.post('/register',(req,res)=>res.json({message:'TODO'}));
module.exports=r;