# SmartEstate Pro - Package 1

This is Package 1 of the SmartEstate Pro project.

Contents:
- Project structure
- Frontend folder
- Backend folder

Next packages will add:
- React app
- Express API
- Database
- Authentication
- Dashboards
