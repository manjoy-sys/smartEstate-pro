import { useState } from "react";

export default function Reviews() {
  const [reviews, setReviews] = useState([]);
  const [text, setText] = useState("");
  function add(e) {
    e.preventDefault();
    if (!text.trim()) return;
    setReviews([...reviews, { id: Date.now(), text }]);
    setText("");
  }
  return <main style={{padding:24}}>
    <h1>Property Reviews</h1>
    <form onSubmit={add}><textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Write a review"/><button>Submit Review</button></form>
    {reviews.map(r=><p key={r.id}>{r.text}</p>)}
  </main>;
}
