# Package 2
Basic React application scaffold.