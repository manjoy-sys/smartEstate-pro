export default function App(){
return <h1>SmartEstate Pro - Package 2</h1>
}