export default function AdminStats({ stats = {} }) {
  return <section><p>Users: {stats.users || 0}</p><p>Properties: {stats.properties || 0}</p><p>Bookings: {stats.bookings || 0}</p></section>;
}
