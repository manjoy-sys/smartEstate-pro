export default function AdminDashboard() {
  return (
    <main style={{padding:24}}>
      <h1>Admin Dashboard</h1>
      <p>Manage users, properties, bookings and platform activity.</p>
    </main>
  );
}
