const router = require("express").Router();
router.get("/", (req, res) => res.json({ users: 0, properties: 0, bookings: 0 }));
module.exports = router;
