const router = require("express").Router();

router.get("/:id", (req, res) => {
  res.json({ id: req.params.id, title: "Sample Property" });
});

module.exports = router;
