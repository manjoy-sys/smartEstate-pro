exports.getProperty = async (req, res) => {
  res.json({ id: req.params.id });
};
