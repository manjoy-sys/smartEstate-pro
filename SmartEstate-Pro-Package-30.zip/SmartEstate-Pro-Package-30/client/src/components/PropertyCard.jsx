export default function PropertyCard({ property }) {
  return (
    <article>
      <h2>{property.title}</h2>
      <p>{property.location}</p>
      <strong>{property.price}</strong>
    </article>
  );
}
