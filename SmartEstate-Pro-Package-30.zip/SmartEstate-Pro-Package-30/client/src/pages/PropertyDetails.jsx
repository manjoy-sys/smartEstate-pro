import { useState } from "react";

export default function PropertyDetails({ property = {} }) {
  const [bookmarked, setBookmarked] = useState(false);
  return (
    <main style={{padding:24}}>
      <h1>{property.title || "Property Details"}</h1>
      <p>{property.location || "Location not provided"}</p>
      <p>{property.description || "Add a property description here."}</p>
      <button onClick={() => setBookmarked(!bookmarked)}>
        {bookmarked ? "Saved" : "Save Property"}
      </button>
    </main>
  );
}
