const router=require('express').Router();
router.get('/',(req,res)=>res.json({items:[]}));
router.post('/',(req,res)=>res.status(201).json({item:req.body,status:'Active'}));
router.put('/:id',(req,res)=>res.json({id:req.params.id,item:req.body}));
module.exports=router;
