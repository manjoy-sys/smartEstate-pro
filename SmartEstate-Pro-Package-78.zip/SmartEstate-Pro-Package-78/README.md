# Package 78 — Favorite Properties
Lets users save and remove favorite properties. Buyer use remains free.