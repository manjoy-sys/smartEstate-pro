import { useState } from "react";

export default function Messages() {
  const [message, setMessage] = useState("");
  const [sent, setSent] = useState([]);

  function send(e) {
    e.preventDefault();
    if (!message.trim()) return;
    setSent([...sent, message.trim()]);
    setMessage("");
  }

  return (
    <main style={{padding:24}}>
      <h1>Messages</h1>
      <div>{sent.map((m, i) => <p key={i}>{m}</p>)}</div>
      <form onSubmit={send}>
        <input value={message} onChange={e => setMessage(e.target.value)} placeholder="Write a message" />
        <button type="submit">Send</button>
      </form>
    </main>
  );
}
