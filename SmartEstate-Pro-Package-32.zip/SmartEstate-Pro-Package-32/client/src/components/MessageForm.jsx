export default function MessageForm() {
  return (
    <form>
      <textarea name="message" placeholder="Write your message" required />
      <button type="submit">Send Message</button>
    </form>
  );
}
