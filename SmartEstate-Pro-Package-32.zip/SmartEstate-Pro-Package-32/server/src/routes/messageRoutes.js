const router = require("express").Router();

router.get("/", (req, res) => res.json({ messages: [] }));
router.post("/", (req, res) => res.status(201).json({ message: req.body }));

module.exports = router;
