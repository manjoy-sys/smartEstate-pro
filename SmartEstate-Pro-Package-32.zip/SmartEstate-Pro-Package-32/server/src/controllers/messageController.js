exports.listMessages = async (req, res) => res.json({ messages: [] });
exports.sendMessage = async (req, res) => res.status(201).json(req.body);
