const router=require("express").Router();
router.get("/",(req,res)=>res.json({user:{}}));
router.put("/",(req,res)=>res.json({user:req.body}));
module.exports=router;
