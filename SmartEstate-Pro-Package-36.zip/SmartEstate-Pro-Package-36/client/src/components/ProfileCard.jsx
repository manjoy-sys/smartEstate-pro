export default function ProfileCard({ user = {} }) {
  return <section><h2>{user.name || "User"}</h2><p>{user.email || "No email"}</p></section>;
}
