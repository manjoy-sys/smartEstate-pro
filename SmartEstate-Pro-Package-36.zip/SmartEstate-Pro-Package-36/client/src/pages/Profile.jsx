import { useState } from "react";

export default function Profile() {
  const [name, setName] = useState("");
  const [saved, setSaved] = useState(false);
  return (
    <main style={{padding:24}}>
      <h1>My Profile</h1>
      <input value={name} onChange={e=>setName(e.target.value)} placeholder="Full name" />
      <button onClick={()=>setSaved(true)}>Save Profile</button>
      {saved && <p>Profile saved.</p>}
    </main>
  );
}
