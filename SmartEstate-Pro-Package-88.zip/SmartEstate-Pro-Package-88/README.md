# Package 88 — Property Valuation Request
Users can request a property valuation. The request itself is free for buyers.