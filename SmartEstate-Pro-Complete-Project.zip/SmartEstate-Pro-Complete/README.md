# SmartEstate Pro — Complete Project

A starter real-estate platform for buyers, renters, agents, owners, developers and advertisers.

## Core rule
BUYERS AND RENTERS DO NOT PAY.
They can browse, search, compare, favorite, contact agents, request viewings and use the public property features for free.

Business users can pay for premium subscriptions, featured listings, extra listings and advertising.

## Run
1. Install Node.js.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm start`.
5. Open http://localhost:3000

This is a working starter/demo project. For real payments, connect the server to M-Pesa/Stripe and use real database/authentication infrastructure. Never put secret keys in frontend code.
