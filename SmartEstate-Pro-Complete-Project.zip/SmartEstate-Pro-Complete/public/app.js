let paymentProduct='';
async function loadProperties(){
 const q=encodeURIComponent(document.getElementById('search').value);
 const type=encodeURIComponent(document.getElementById('type').value);
 const res=await fetch(`/api/properties?q=${q}&type=${type}`); const items=await res.json();
 document.getElementById('propertyGrid').innerHTML=items.map(p=>`
 <article class="property">
 <div style="height:160px;background:#dce5f3;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:45px">🏠</div>
 <h3>${p.title}</h3><p>${p.location} · ${p.type}</p><h3>KSh ${Number(p.price).toLocaleString()}</h3>
 <p>${p.status}</p><p class="muted">${p.amenities.join(' · ')}</p>
 <button class="btn" onclick="requestViewing(${p.id})">Request Viewing</button>
 </article>`).join('') || '<p>No properties found.</p>';
}
async function requestViewing(id){
 const name=prompt('Your name'); if(!name)return;
 const res=await fetch('/api/viewings',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({propertyId:id,name})});
 alert(res.ok?'Viewing request sent.':'Unable to send request.');
}
function openPayment(product,amount){paymentProduct=product;document.getElementById('payAmount').value=amount;document.getElementById('modal').classList.remove('hidden')}
function closePayment(){document.getElementById('modal').classList.add('hidden')}
async function pay(e){e.preventDefault();
 const amount=Number(document.getElementById('payAmount').value),method=document.getElementById('payMethod').value;
 const res=await fetch('/api/payments/create',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({amount,product:paymentProduct,method,userType:'business'})});
 const data=await res.json(); document.getElementById('payResult').textContent=res.ok?`Payment ${data.status}. Connect your provider to collect real money.`:(data.error||'Payment failed');
}
async function sendEnquiry(e){e.preventDefault();const body={name:document.getElementById('name').value,email:document.getElementById('email').value,message:document.getElementById('message').value};const r=await fetch('/api/enquiries',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});document.getElementById('contactResult').textContent=r.ok?'Message sent successfully.':'Could not send message.'}
loadProperties();