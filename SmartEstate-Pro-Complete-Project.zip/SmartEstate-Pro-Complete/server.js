const express=require('express');
const path=require('path');
const app=express();
app.use(express.json());
app.use(express.static(path.join(__dirname,'public')));

const properties=[
 {id:1,title:'Modern Family Home',location:'Nairobi',price:8500000,type:'House',status:'For Sale',agent:'SmartEstate Agent',featured:true,amenities:['Parking','Garden','Security']},
 {id:2,title:'City Apartment',location:'Nairobi',price:45000,type:'Apartment',status:'For Rent',agent:'SmartEstate Agent',featured:true,amenities:['Security','Lift','Parking']},
 {id:3,title:'Development Land',location:'Kiambu',price:3200000,type:'Land',status:'For Sale',agent:'SmartEstate Agent',featured:false,amenities:['Road Access','Electricity']}
];

const payments=[];
const enquiries=[];
const viewings=[];
const reports=[];

app.get('/api/properties',(req,res)=>{
  const q=(req.query.q||'').toLowerCase();
  const type=(req.query.type||'').toLowerCase();
  let result=properties.filter(p=>
    (!q || [p.title,p.location,p.type,p.status].join(' ').toLowerCase().includes(q)) &&
    (!type || p.type.toLowerCase()===type)
  );
  res.json(result);
});
app.get('/api/properties/:id',(req,res)=>{
  const p=properties.find(x=>x.id===Number(req.params.id));
  p ? res.json(p) : res.status(404).json({error:'Property not found'});
});
app.post('/api/viewings',(req,res)=>{
  const v={id:Date.now(),...req.body,status:'Requested'};
  viewings.push(v); res.status(201).json(v);
});
app.post('/api/enquiries',(req,res)=>{
  const e={id:Date.now(),...req.body,status:'New'};
  enquiries.push(e); res.status(201).json(e);
});
app.post('/api/reports',(req,res)=>{
  const r={id:Date.now(),...req.body,status:'Under review'};
  reports.push(r); res.status(201).json(r);
});

// Business-only payments. Buyers/renters are rejected.
const paidProducts=new Set(['agent_pro','business_plan','featured_listing','extra_listing','advertising']);
app.post('/api/payments/create',(req,res)=>{
  const {amount,product,userType='business',method='M-Pesa'}=req.body||{};
  if(userType==='buyer'||userType==='renter')
    return res.status(403).json({error:'Buyers and renters do not pay on SmartEstate Pro.'});
  if(!paidProducts.has(product))
    return res.status(400).json({error:'Unsupported business product.'});
  if(!Number.isFinite(Number(amount)) || Number(amount)<=0)
    return res.status(400).json({error:'Enter a valid amount.'});
  const payment={id:Date.now(),amount:Number(amount),product,method,status:'Pending'};
  payments.push(payment);
  res.status(201).json(payment);
});
app.get('/api/payments',(req,res)=>res.json(payments));

app.get('*',(req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(3000,()=>console.log('SmartEstate Pro running at http://localhost:3000'));
