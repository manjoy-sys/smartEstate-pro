# Deployment checklist

- Install Node.js 18+.
- Run `npm install`.
- Run `npm start`.
- For production, use HTTPS.
- Add a database for users, properties and transactions.
- Add secure authentication and role-based access.
- Connect a server-side M-Pesa or Stripe SDK.
- Configure provider callbacks/webhooks.
- Store secrets only in environment variables.
- Verify payment status with the provider before activating paid features.
- Keep buyer/renter access free.
