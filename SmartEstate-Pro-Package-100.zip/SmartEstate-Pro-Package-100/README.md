# Package 100 — User Accounts & Roles
Role foundation for buyers, renters, agents, owners, developers and administrators.