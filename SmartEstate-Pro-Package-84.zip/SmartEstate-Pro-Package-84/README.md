# Package 84 — Property Search Filters
Advanced property search filters for location, type, price and status.